<form class="form-inline" id="searchform" role="search" method="get" action="<?php echo home_url( '/' ); ?>">
	<input class="form-control" id="s" name="s" type="text" placeholder="<?php echo __('Search', 'wp_babobski'); ?>">
	<button class="btn btn-outline-success" type="submit">
		<?php echo __('Search', 'wp_babobski'); ?>
	</button>
</form>
